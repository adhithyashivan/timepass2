# Databricks notebook source
# MAGIC %pip install fastapi uvicorn pydantic aiohttp nest-asyncio

# COMMAND ----------

